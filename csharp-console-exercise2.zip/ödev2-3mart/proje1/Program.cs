﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    //Kullanıcının girdiği sayıyı Roma rakamlarıyla yazan uygulamayı geliştirin.Girilen değeri kontrol edin.Roma rakamlarıyla yazılabilen en büyük sayıyı dikkate alın.Daha büyük girilmişse uyarı verin.Negatif sayı girdiyse uyarı verin.Kontrolden geçtiyse sayı Roma rakamlarıyla yazılmış halini ekrana yazdırın. (İnternetten Roma rakamlarına bakın)

namespace proje1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Girilen sayiyi istenilen aralıkta mı kontrol et istenilen aralıkta ise roma rakamına çevir.
                Console.WriteLine("sayi giriniz");
                string sayi = Console.ReadLine();
                int deger = int.Parse(sayi);

                İstenilenAralıkdaMı(deger);
                Console.WriteLine(RomaRakamCevir(deger));
            }
            catch
            {
                Console.WriteLine("beklenmedik değer gridiniz");
            }
            Console.Read();

        }
        //girilen değer 2500'den  büyük olmamalı.Negatif olmamalı.0 olmamalı
        static int İstenilenAralıkdaMı(int deger)
        {
          
            if (deger > 2500)
            {
                Console.WriteLine("2500'den büyük bi sayi girdiniz.tekrar deneyin.");
            }
            else if (deger < 0)
            {
                Console.WriteLine("negatif bir sayi girdiniz.Tekrar deneyin.");
            }
            else if (deger == 0)
            {
                Console.WriteLine("0 girdiniz.Roma rakamında bu deger yok .tekrar deneyiniz.");

            }
            return deger;
        }



        static string RomaRakamCevir(int deger)
        {
          
            string metin = string.Empty;
            int birler = 0;
            int onlar = 0;
            int yuzler = 0;
            int binler = 0;
            string[] birlerBasamak = { "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX" };
            string[] onlarBasamak = { "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC" };
            string[] yuzlerBasamak = { "", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM" };
            string[] binlerBasamak = { "M", "MM","MMM" };
            //girilen sayının aralıgına göre basamak değerini hesapla
            //roma rakamlarını basamaklara ekle
            if (deger < 10)
            {
                birler = deger;
                metin += birlerBasamak[birler];
            }

            if (deger > 9 && deger < 100)
            {
                onlar = deger / 10;
                birler = deger - (onlar * 10);
                metin += onlarBasamak[onlar];
                metin += birlerBasamak[birler];
            }

            if (deger > 99 && deger < 1000)
            {
                yuzler = deger / 100;
                onlar = (deger - (yuzler * 100)) / 10;
                birler = deger - ((yuzler * 100) + (onlar * 10));
                metin += yuzlerBasamak[yuzler];
                metin += onlarBasamak[onlar];
                metin += birlerBasamak[birler];

            }

            if (deger > 999 && deger < 2501)
            {
                binler = deger / 1000;
                yuzler = (deger - (binler * 1000)) / 100;
                onlar = (deger - ((binler * 1000) + (yuzler * 100))) / 10;
                birler = (deger-((binler*1000)+(yuzler*100)+(onlar*10)));
                metin += binlerBasamak[binler];
                metin += yuzlerBasamak[yuzler];
                metin += onlarBasamak[onlar];
                metin += birlerBasamak[birler];
            }


            return metin;
        }


    }
}
