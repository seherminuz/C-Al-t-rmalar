﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Kullanıcının “THE END” diyene kadar alışveriş fişlerini girebileceği bir uygulama geliştirin.Kullanıcı fişin tarihini, “END” diyene kadar içerdiği ürünlerin fiyatlarını ve KDV oranlarını sırasıyla girebilmeli. “THE END” diyip fiş girmeyi bitirdiğinde toplam harcamasını ekrana yazdırın. Sonrasında uygulama “Tarih bazlı harcama tutarını görmek ister misiniz? (E/H)” diye sorsun.Evet derse “01.01.2000” formatında tarih bilgisi isteyin. Girdiği tarihteki toplam harcama tutarını gösterin. Sonra tekrar sorun.Hayır derse uygulama sonlansın.

namespace proje2
{
    class Program
    {
        static void Main(string[] args)
        {

            string tarih = string.Empty;
            string urun= string.Empty;
            UrunleriGir(urun);
            FisTarihleriGir(tarih);

            for(int i=0;i<tarih.Length;i++)
            {

            }

          
            



            Console.Read();
        }
        static string FisTarihleriGir(string tarih)
        {
            string[] tarihDizi = new string[0];
            Console.WriteLine("tarih girişini sonlandırmak için  THE END yazın");
            do
            {
                Console.WriteLine("tarih girin");
                tarih = Console.ReadLine();
            
                Array.Resize(ref tarihDizi, tarihDizi.Length + 1);
                tarihDizi[tarihDizi.Length - 1] = tarih;

            } while (tarih != "THE END");

            Array.Sort(tarihDizi);
            foreach (string item in tarihDizi)
            {
                Console.WriteLine(item);
            }
            return tarih;
        }
        static string UrunleriGir(string urun)
        {
            string[] urunDizi = new string[0];
            Console.WriteLine("urun girişini sonlandırmak için END yazın");
            do
            {
                Console.WriteLine("urun girin");
                urun = Console.ReadLine();

                Array.Resize(ref urunDizi, urunDizi.Length + 1);
                urunDizi[urunDizi.Length - 1] = urun;

            } while (urun != " END");

            Array.Sort(urunDizi);
            foreach (string item in urunDizi)
            {
                Console.WriteLine(item);
            }
            return urun;
        }
      
    }
}
